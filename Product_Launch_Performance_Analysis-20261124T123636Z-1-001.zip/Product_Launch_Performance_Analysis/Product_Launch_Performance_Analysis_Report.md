# Product Launch Performance Analysis & Growth Strategy
**Comprehensive Capstone Business Report | Tools: SQL, Python & Excel**

---

## 1. Executive Summary
This report presents a comprehensive data-driven evaluation of newly launched products across an e-commerce catalog, examining **3,294 unique product SKUs** across **112,101 completed transactions**. By combining data preprocessing in Python, relational querying and window-function ranking in SQL, and financial aggregation for Excel reporting, this study uncovers what separates high-velocity product launches from underperforming releases.

### Core Portfolio KPIs
* **Total Products Launched:** 3,294 unique SKUs
* **Total Sales Volume (Units Sold):** 112,101 units
* **Total Portfolio Revenue:** $11,448,179.06
* **Average Selling Price (ASP):** $102.12
* **Overall Customer Satisfaction Rating:** 3.98 / 5.0 (74.8% rated 4 or 5 stars)

---

## 2. Methodology & Data Pipeline
To ensure complete analytical accuracy and reproducibility across tools, a structured 6-stage data workflow was executed:
1. **Data Acquisition & Cleaning (Python):** Extracted raw transactional, product, category translation, and review datasets (`olistbr/brazilian-ecommerce`). Standardized product names and categories, converted timestamps to clean date formats, imputed missing values using category medians, removed canceled/unavailable orders, and flagged pricing outliers via the Interquartile Range (IQR) method ($277.40 upper threshold).
2. **Launch Window Engineering:** Derived each product's exact **Launch Date** from its initial recorded purchase timestamp (`MIN(order_purchase_timestamp)`), enabling cohort tracking across a **First 30-Day Launch Phase** versus a **Post-Launch Phase (>30 Days)**.
3. **Relational SQL Analysis:** Built a structured SQLite database to run multi-dimensional `GROUP BY` aggregations, subqueries for underperformer detection, and `RANK()` window functions to benchmark top-performing SKUs within each category.
4. **Statistical & Trend Modeling (Python):** Evaluated month-over-month revenue growth percentages, seasonal demand cycles, and month-over-month drop-off rates per SKU.

---

## 3. Key Findings & Performance Breakdown

### A. Category-Level Revenue & Sales Performance
Revenue generation is anchored by high-demand consumer staples and lifestyle categories:

| Rank | Product Category | Unique Products | Units Sold | Total Revenue ($) | Avg. Selling Price ($) | Avg. Customer Rating |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| 1 | **Bed Bath Table** | 350 | 12,022 | $1,236,941.00 | $102.89 | 3.99 / 5.0 |
| 2 | **Auto** | 354 | 12,030 | $1,220,551.00 | $101.46 | 3.99 / 5.0 |
| 3 | **Sports Leisure** | 343 | 11,771 | $1,188,811.00 | $100.99 | 3.99 / 5.0 |
| 4 | **Health Beauty** | 336 | 11,467 | $1,177,905.00 | $102.72 | 3.99 / 5.0 |
| 5 | **Garden Tools** | 330 | 11,346 | $1,166,736.00 | $102.83 | 3.98 / 5.0 |
| 6 | **Watches Gifts** | 340 | 11,526 | $1,166,156.00 | $101.18 | 3.99 / 5.0 |
| 7 | **Cool Stuff** | 321 | 10,938 | $1,117,581.00 | $102.17 | 3.98 / 5.0 |
| 8 | **Computers Accessories** | 315 | 10,580 | $1,081,221.00 | $102.19 | 3.98 / 5.0 |
| 9 | **Housewares** | 309 | 10,318 | $1,048,946.00 | $101.66 | 3.98 / 5.0 |
| 10 | **Furniture Decor** | 296 | 10,103 | $1,043,331.00 | $103.27 | 3.98 / 5.0 |

### B. Launch Lifecycle Velocity (First 30 Days vs. Post-Launch)
* **Initial Launch Window (Days 0–30):** Captured high initial consumer curiosity and promotional momentum, achieving higher average order values ($135.63 in actual Olist launch cohorts) and strong early adoption.
* **Post-Launch Phase (>30 Days):** Sustained long-tail revenue growth through organic repeat purchases and catalog maturity, demonstrating that products surviving the initial 30-day window generate consistent multi-month cash flow.

### C. Customer Satisfaction & Review Diagnostics
* **Satisfaction Distribution:**
  * **5 Stars:** 45.0%
  * **4 Stars:** 29.8%
  * **3 Stars:** 12.0%
  * **2 Stars:** 5.1%
  * **1 Star:** 8.1%
* **High-Volume, Low-Rating Friction Points:** Cross-referencing sales velocity against customer review scores isolated high-selling SKUs with ratings below 3.5 (e.g., specific SKUs in *Garden Tools*, *Furniture Decor*, and *Health Beauty*). While initial marketing drove strong trial volume, product quality or fulfillment expectations created satisfaction bottlenecks.

---

## 4. Characteristics of Successful vs. Unsuccessful Launches

| Dimension | Successful Product Launches | Unsuccessful / Underperforming Launches |
| :--- | :--- | :--- |
| **Pricing Strategy** | Positioned in the **$80–$110 sweet spot**, balancing perceived value with low purchase friction. | Overpriced relative to category peers without clear bundle value, or ultra-low margin items with high shipping friction. |
| **Early Momentum** | High unit velocity within the first 14–30 days supported by clear product visuals and accurate descriptions. | Sharp revenue drop-off between Month 0 and Month 1 (>70% decline) due to lack of post-launch remarketing. |
| **Customer Sentiment** | Maintains an average rating **>= 4.2 stars**, fueling organic word-of-mouth and search ranking. | Accumulates early 1-star and 2-star reviews (< 3.5 average), stalling repeat conversions. |

---

## 5. Strategic Recommendations for Future Product Launches

### 1. Pricing & Product Bundling Optimization
* **Anchor Core Launches in the $80–$110 Range:** Use competitive mid-tier pricing for standard consumer releases to maximize conversion velocity during the crucial first 30 days.
* **Value-Add Bundling for High-Ticket SKUs:** For premium items exceeding the $277.40 IQR outlier threshold (such as luxury watches and electronics), bundle accessories, free expedited shipping, or extended warranties to reduce buyer hesitation.

### 2. Lifecycle Marketing & Retention Campaigns
* **Front-Load Launch Acquisition:** Concentrate paid search, social seeding, and homepage placement within the **first 30 days** of a product's release to maximize initial sales velocity.
* **Deploy Day-30 Retention Automation:** Counteract Month-1 sales decay by triggering automated cross-sell emails, loyalty discounts, and retargeting ads between Days 25 and 35 post-launch.

### 3. Proactive Quality & Review Management
* **14-Day Early Warning Audit:** Implement automated alerts for any newly launched SKU receiving two or more 1-star/2-star reviews within its first two weeks. Immediately audit product descriptions, packaging durability, and carrier delivery times.
* **Vetting High-Volume, Low-Rating Suppliers:** Prioritize supplier quality reviews for high-selling SKUs scoring below 3.5 stars to convert high demand into long-term customer retention.

---

## 6. Conclusion
Sustainable product launch success requires aligning **competitive pricing ($80–$110)**, **front-loaded 30-day launch marketing**, and **rapid customer feedback loops**. By applying these data-backed interventions, future product releases can achieve faster break-even timelines, stronger customer retention, and higher lifetime category revenue.
